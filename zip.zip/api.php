<?php
require ("vendor/slim/slim/Slim/Slim.php");
require ("Database.php");
\Slim\Slim::registerAutoloader();
define('PATH', $_SERVER['SERVER_NAME']);

$app = new \Slim\Slim();

/**
 * @api {get} /api/v1/jobs/:id Get Job Status
 * @apiParam {Number} id Unique job ID.
 * @apiDescription Returns the status of the current job.
 * @apiGroup Jobs
 * @apiName GetJob
 * @apiVersion 1.0.0
 * @apiExample {curl} Example usage:
 *     curl -X GET 'http://pyro.demo/api/v1/jobs/1'
 * @apiError (400 Bad Request) {Number} response 400
 * @apiError (400 Bad Request) {String} message The ID supplied is invalid or does not exist.
 * @apiSuccess (200 OK) {Number} id ID of current job.
 * @apiSuccess (200 OK) {String} name Name of the uploaded file.
 * @apiSuccess (200 OK) {Number} timestamp Timestamp of when file was uploaded.
 * @apiSuccess (200 OK) {String} status Status of the current job.
 * @apiSuccess (200 OK) {Number} progress Current progress of the job.
 */
$app->get('/api/v1/jobs/:id', function ($id) use ($app) 
{
	DB::FindJob($id, $app);
});

/**
 * @api {get} /api/v1/list/ Get All Jobs
 * @apiDescription Returns a list of running and completed jobs.
 * @apiGroup Jobs
 * @apiName GetJobs
 * @apiVersion 1.0.0
 * @apiExample {curl} Example usage:
 *     curl -X GET 'http://pyro.demo/api/v1/list/'
 * @apiError (400 Bad Request) {Number} response 400
 */

// Show a list of running and completed tasks.
$app->get('/api/v1/list/', function () use ($app) 
{
	
	// Grab the list of files.
	//$db->ListJobs();
	DB::ListJobs($app);
	
	// Display the list.
	
});

/**
 * @api {delete} /api/v1/delete/:id Delete a Job
 * @apiDescription Deletes the specified job.
 * @apiGroup Jobs
 * @apiName DeleteJob
 * @apiVersion 1.0.0
 * @apiExample {curl}  Example usage:
 *      curl -X DELETE 'http://pyro.demo/api/v1/delete/1'
 * @apiError (400 Bad Request) {Number} response 400
 */
$app->delete('/api/v1/delete/:id', function ($id) use ($app) 
{
	DB::DeleteJob($id, $app);
});

/**
 * @api {get} /api/v1/download/:id Download Finished Job
 * @apiDescription Downloads a finished job.
 * @apiGroup Jobs
 * @apiName DownloadJob
 * @apiVersion 1.0.0
 * @apiExample {curl} Example usage:
 *      curl -X GET 'http://pyro.demo/api/v1/download/1'
 */
$app->get('/api/v1/download/:id', function ($id) use ($app) 
{
	
	//print $id;
	
	// Get the job to be downloaded.
	//        $job = DB::FindJob($id, $app);
	//        echo $id . "<br />";
	//        $job["timestamp"] = 1446044514;
	//        // Create the zip.
	//        $zip = new ZipArchive();
	//        echo "uploads/" . $job["timestamp"] . "/" . $job["timestamp"] . ".zip<br />";
	//        // Add everything except the original FDS file to the list of stuff to zip.
	//        $zip->open("uploads/" . $job["timestamp"] . "/" . $job["timestamp"] . ".zip", ZipArchive::CREATE);
	//        $files = scandir(".");
	//        foreach($files as $f){
	//            echo $f;
	//            if(substr($f, -4) !== ".fds"){  // Don't include the original FDS file.
	//                $zip->addFile($f);
	//            }
	//        }
	//        $zip->close();
	//
	//        // Now make it available for download.
	//        return $zip;
	chmod(".", 0777);
	$zip = new ZipArchive();
	$files = scandir(".");
	$zip->open("zip.zip", ZipArchive::CREATE);
	var_dump($zip);
	foreach ($files as $f) 
	{
		$zip->addFile($f);
	}
	$res = $zip->close();
	var_dump($res);
});

/**
 * @api {post} /api/v1/jobs Upload Job
 * @apiDescription Uploads a new job.
 * @apiGroup Jobs
 * @apiName UploadJob
 * @apiVersion 1.0.0
 * @apiExample {curl} Example usage:
 *      curl -X POST -F 'file=@example.fds' 'http://pyro.demo/api/v1/jobs'
 */
$app->post('/api/v1/jobs/', function () use ($app) 
{
	$ext = pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
	if ($_FILES["file"]["type"] != "application/octet-stream" || $ext != "fds") 
	{
		echo "You have uploaded an invalid file.\n";
	} 
	else
	{
		
		// Make sure the uploads file exists.
		if (!file_exists('uploads')) 
		{
			mkdir('uploads', 0777, true);
		}
		
		// Make sure the completed file exists.
		if (!file_exists('completed')) 
		{
			mkdir('completed', 0777, true);
		}
		
		// Create the folder for the simulation and put it in there.
		$target = "uploads/" . time();
		mkdir($target);
		if (move_uploaded_file($_FILES["file"]["tmp_name"], $target . "/" . basename($_FILES["file"]["name"]))) 
		{
			echo DB::AddJob($_FILES["file"]["name"]);
			
			//echo json_encode(array("message" => "The file " . $_FILES["file"]["name"] . " has been uploaded."));
			
		} 
		else
		{
			return FALSE;
		}
	}
});

// Run the code.
$app->run();
?>