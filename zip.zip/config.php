<?php if ( ! defined('BASEPATH')) exit('Ah ah ah, you didn\'t say the magic word.');

$config['key'] = 'jfidsoafj849f893hfqhq348jf34qo8';

?>